# -*- coding: utf-8 -*-
"""
Created on Fri Dec  4 09:40:38 2020

@author: 沈明楷
"""



from tkinter import *

win1=Tk()
win1.mainloop()