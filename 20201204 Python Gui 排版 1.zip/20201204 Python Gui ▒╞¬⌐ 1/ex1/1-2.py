# -*- coding: utf-8 -*-
"""
Created on Fri Dec  4 09:55:12 2020

@author: 沈明楷
"""


from tkinter import *

win1=Tk()
win1.title("smile")
win1.geometry("600x400+10+10")#長 寬 位置
win1.maxsize(500,300)
win1.minsize(400,100)
win1.configure(bg="#B22222")
               
               
#win1.resizable(0,0)#鎖定視窗長寬
#win1.state("zoomed")#最大化視窗
#win1.iconify()#縮小視窗
win1.iconbitmap(".\icon1.ico")#表單icon          

win1.mainloop()