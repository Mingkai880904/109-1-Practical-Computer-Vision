# -*- coding: utf-8 -*-
"""
Created on Fri Dec  4 10:21:53 2020

@author: 沈明楷
"""


from tkinter import *

ui=Tk()
ui.title("ex3")
ui.configure(bg="lightyellow")

screen_w=ui.winfo_screenwidth() #screen_w
screen_h=ui.winfo_screenheight() #screen_h


print(screen_w,screen_h)


w=screen_w/3  #設定視窗 寬度為螢幕三分之一
h=screen_h/3  #設定視窗 高度為螢幕三分之一

x=(screen_w-w)/2 #設定視窗x軸 為視窗x軸一半 
y=(screen_h-h)/2 #設定視窗y軸 為視窗y軸一半  

ui.geometry("%dx%d+%d+%d"%(w,h,x,y))
ui.mainloop()