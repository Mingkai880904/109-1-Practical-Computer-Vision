# -*- coding: utf-8 -*-
"""
Created on Fri Dec  4 11:24:34 2020

@author: 沈明楷
"""


from tkinter import *
from PIL import Image,ImageTk

ui=Tk()
ui.title("ex3")
ui.configure(bg="lightyellow")

screen_w=ui.winfo_screenwidth() #screen_w
screen_h=ui.winfo_screenheight() #screen_h


print(screen_w,screen_h)


w=screen_w/3  #設定視窗 寬度為螢幕三分之一
h=screen_h/2  #設定視窗 高度為螢幕二分之一

x=(screen_w-w)/2 #設定視窗x軸 為視窗x軸一半 
y=(screen_h-h)/2 #設定視窗y軸 為視窗y軸一半  

ui.geometry("%dx%d+%d+%d"%(w,h,x,y))

"""-------------------------------------------------------------"""
jpg1=Image.open("ex2.jpg")#開啟圖片
jpg1_w,jpg1_h=jpg1.size#回傳圖片長寬
print(jpg1_w,jpg1_h)#測試
re=0.6#設定縮放比例
jpg1_resize=jpg1.resize((int(jpg1_w*re),int(jpg1_h*re)))#重新定義圖片大小
jpg1_tk=ImageTk.PhotoImage(jpg1_resize)#將新圖片回傳至jpg1_tk



lab1=Label(ui,
           text="我是標籤",#文字內容
           bg="#3355aa",
           #width=20,
           #height=5,
           font="標楷體 20 bold underline overstrike",
           fg="#ffffff",
           #anchor="nw", #文字方位
           relief="groove",#邊框樣式
           bd=5 ,#邊框寬度
           padx=10,
           pady=10,          
           image=jpg1_tk,      #加入圖片
           compound="bottom"#圖片在文字下方
           )
lab1.pack()
ui=mainloop()
